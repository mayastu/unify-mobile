import 'package:unify/features/payment/data/models/payment_response_model.dart';
import '../models/payment_request_model.dart';

abstract class PaymentRemoteDataSource {
  Future<PaymentResponseModel> createPayment({
    required PaymentRequestModel request,
  });
}
