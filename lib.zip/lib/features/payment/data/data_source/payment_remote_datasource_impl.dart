import 'package:unify/core/api/api_consumer.dart';
import 'package:unify/core/api/end_points.dart';
import 'package:unify/features/payment/data/data_source/payment_remote_datasource.dart';
import 'package:unify/features/payment/data/models/payment_request_model.dart';
import 'package:unify/features/payment/data/models/payment_response_model.dart';

class PaymentRemoteDataSourceImpl implements PaymentRemoteDataSource {
  final ApiConsumer api;
  PaymentRemoteDataSourceImpl(this.api);

  @override
  Future<PaymentResponseModel> createPayment(
      {required PaymentRequestModel request}) async {
    final response = await api.post(
      EndPoints.createPayment,
      data: request.toJson(),
    );
    return PaymentResponseModel.fromJson(response);
  }

}
