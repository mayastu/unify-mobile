import '../data_source/payment_remote_datasource.dart';
import '../models/payment_request_model.dart';
import '../models/payment_response_model.dart';
import 'payment_repository.dart';

class PaymentRepositoryImpl implements PaymentRepository {
  final PaymentRemoteDataSource remoteDataSource;

  PaymentRepositoryImpl(this.remoteDataSource);

  @override
  Future<PaymentResponseModel> createPayment({
    required PaymentRequestModel request,
  }) {
    return remoteDataSource.createPayment(
      request: request,
    );
  }
}