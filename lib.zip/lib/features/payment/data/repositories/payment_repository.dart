import '../models/payment_request_model.dart';
import '../models/payment_response_model.dart';

abstract class PaymentRepository {
  Future<PaymentResponseModel> createPayment({
    required PaymentRequestModel request,
  });
}