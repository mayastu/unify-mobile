import '../../data/models/payment_response_model.dart';

abstract class PaymentState {}

class PaymentInitial extends PaymentState {}

class PaymentLoading extends PaymentState {}

class PaymentSuccess extends PaymentState {
  final PaymentResponseModel response;

  PaymentSuccess(this.response);
}

class PaymentFailure extends PaymentState {
  final String message;

  PaymentFailure(this.message);
}