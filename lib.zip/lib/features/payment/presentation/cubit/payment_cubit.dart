import 'package:flutter_bloc/flutter_bloc.dart';
import 'package:unify/features/payment/data/models/payment_request_model.dart';
import 'package:unify/features/payment/data/repositories/payment_repository.dart';
import 'package:unify/features/payment/presentation/cubit/payment_state.dart';

class PaymentCubit extends Cubit<PaymentState> {
  final PaymentRepository repository;
  PaymentCubit(this.repository) : super(PaymentInitial());
  Future<void> createPayment(
      {required int studentId,
      required double amount,
      required String referenceNumber,
      required String paymentDate}) async {
    emit(PaymentLoading());

    try {
      final response = await repository.createPayment(
          request: PaymentRequestModel(
              studentId: studentId,
              amount: amount,
              referenceNumber: referenceNumber,
              paymentDate: paymentDate));
      emit(PaymentSuccess(response));
    } catch (e) {
      emit(PaymentFailure(e.toString()));
    }
  }
}
