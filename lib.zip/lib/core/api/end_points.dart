class EndPoints{
  const EndPoints._();
  static const String baseUrl = 'http://192.168.2.2:8000/api';

  static const String login="/login";
  static const String logout = '/logout';
  static const String forgotPassword = '/forgot-password';
  static const String verifyOtp = '/verify-otp';
  static const String resetPassword = '/reset-password';
  static const String getProfile = "/students/profile";
  static const String semesters = "/semesters";
  static const String createPayment = "/payments";
  static const String financialAccount = "/financial-accounts";
  static const String hourPurchases = "/hour-purchases";

}